﻿namespace FindBeeNumbers.Core.Model
{
    public class Provider
    {
        public string Name { get; set; }
        public string[] Prefixes { get; set; }
    }
}
