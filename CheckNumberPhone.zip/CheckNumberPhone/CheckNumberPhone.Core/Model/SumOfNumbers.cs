﻿namespace FindBeeNumbers.Core.Model
{
    public class SumOfNumbers
    {
        public string FromFirst { get; set; }
        public string FromLast { get; set; }
    }
}
